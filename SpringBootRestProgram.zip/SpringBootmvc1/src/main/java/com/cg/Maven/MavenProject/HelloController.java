package com.cg.Maven.MavenProject;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.MavenFinalapplication.bean.Employee;


@RestController
public class HelloController {
	
	@RequestMapping(value="/welcome",method=RequestMethod.GET)
	public String printHello() {
		return"hello";
		
	}
	
	@RequestMapping(value="/getEmployee",method=RequestMethod.GET,produces="application/json")
	public Employee getEmployeeDetails(){
		Employee emp = new Employee();
		emp.setFirstName("kavita");
		emp.setLastName("sharma");
		emp.setMobileNo("9997026135");
		emp.setEmail("kavita4797@gmail.com");
		return emp;
		
	}
	@RequestMapping(value="/addEmployee",method=RequestMethod.POST)
	public String addEmployee(@RequestParam("fname")String firstname,
			@RequestParam("lname")String lastname,@RequestParam("mobno")String mobno,
			@RequestParam("email")String email) {
		Employee emp= new Employee();
		
		emp.setFirstName(firstname);
		emp.setLastName(lastname);
		emp.setMobileNo(mobno);
		emp.setEmail(email);
		return "Employee added Succesfully";
		
	}
	

}
